CREATE TYPE PLATE_NUM AS (
  plate_char CHAR(3),
  plate_number NUMERIC(4,0));
