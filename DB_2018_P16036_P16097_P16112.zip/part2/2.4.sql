SELECT
    *
FROM
    service_history
WHERE
    end_date IS NULL